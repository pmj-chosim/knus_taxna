package knu.java.lsy.apiTemplate;

import jakarta.websocket.OnClose;
import jakarta.websocket.OnMessage;
import jakarta.websocket.OnOpen;
import jakarta.websocket.Session;
import jakarta.websocket.server.ServerEndpoint;
import knu.java.lsy.UTILS.UTIL;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;
import org.springframework.web.socket.server.standard.ServerEndpointExporter;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

@ServerEndpoint(value = "/api")
@Service
@Component
public class API_WS {
    static String TAG = API_WS.class.getName();
    private static Set<Session> CLIENTS = Collections.synchronizedSet(new HashSet<>());

    @OnOpen
    public void onOpen(Session session) {
        if (CLIENTS.contains(session)) {
            UTIL.LOG(5, TAG, String.format("%s 는 이미 연결된 세션입니다.", session));
        } else {
            CLIENTS.add(session);
            UTIL.LOG(5, TAG, String.format("새로운 세션 %s 으로 연결되었습니다.", session));
        }
    }

    @OnClose
    public void onClose(Session session) throws Exception {
        CLIENTS.remove(session);
        UTIL.LOG(5, TAG, String.format("연결된 세션 %s 을 닫습니다.", session));
    }

    @OnMessage
    public void onMessage(String message, Session session) throws Exception {
        UTIL.LOG(5, TAG, String.format("세션 %s 에서 %s 를 전달받았습니다.", session, message));
        for (Session client : CLIENTS) {
            UTIL.LOG(5, TAG, String.format("세션 %s 에게 %s 를 전달합니다.", client, message));
            client.getBasicRemote().sendText(message);
        }
    }

    @Bean
    public ServerEndpointExporter serverEndpointExporter() {
        return new ServerEndpointExporter();
    }

}
