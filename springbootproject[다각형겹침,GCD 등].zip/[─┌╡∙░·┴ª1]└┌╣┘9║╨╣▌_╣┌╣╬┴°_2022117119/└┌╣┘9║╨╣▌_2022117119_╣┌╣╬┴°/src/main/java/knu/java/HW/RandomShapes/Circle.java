package knu.java.HW.RandomShapes;

public class Circle extends Shape {
    public int radius;

    public void make_Circle(
            int Width,
            int Height,
            int MinRadius,
            int MaxRadius
    ) {
            center_x = (int) (Math.random() * (Width - MaxRadius * 2) + MaxRadius);
            center_y = (int) (Math.random() * (Height - MaxRadius * 2) + MaxRadius);
            radius = (int) (Math.random() * Math.abs(MaxRadius - MinRadius) + (MaxRadius > MinRadius ? MinRadius : MaxRadius));
    }

}
