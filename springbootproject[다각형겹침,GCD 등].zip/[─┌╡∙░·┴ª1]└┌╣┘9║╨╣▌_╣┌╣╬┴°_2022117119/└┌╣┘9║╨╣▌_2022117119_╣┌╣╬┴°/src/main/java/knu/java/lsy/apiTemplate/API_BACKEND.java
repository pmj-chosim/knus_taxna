package knu.java.lsy.apiTemplate;

import knu.java.HW.GCD;
import knu.java.HW.PerfectNumber;
import knu.java.HW.RC.RandomCircles;
import knu.java.HW.RP.RandomPolygons;
import knu.java.HW.RandomShapes.ShapeMaker;
import knu.java.HW.ShapesOverlaps.MakeShapesAndSorter;
import knu.java.lsy.UTILS.UTIL;
import org.json.JSONObject;


public class API_BACKEND {

    static String TAG = API_BACKEND.class.getName();

    public static boolean IS_EXIST_ARGS(JSONObject args_JSON, String[] args_ARRAY) {
        JSONObject JSON_REQ = args_JSON.getJSONObject("REQ");
        JSONObject JSON_RES = args_JSON.getJSONObject("RES");
        boolean b_EXIST = true;
        for (String s : args_ARRAY) {
            if (!JSON_REQ.has(s)) {
                JSON_RES.put("STATUS", 400);
                JSON_RES.put("STATUS_MSG", String.format("[%s] 인자를 전달받지 못하였습니다.", s));
                b_EXIST = false;
                break;
            }
        }
        return b_EXIST;
    }
    public static JSONObject DO_REQ(JSONObject args_JSON) {
        JSONObject JSON_REQ = args_JSON.getJSONObject("REQ");
        JSONObject JSON_RES = args_JSON.getJSONObject("RES");

        UTIL.LOG(5, TAG, JSON_REQ.toString(2));

        if (!IS_EXIST_ARGS(args_JSON, new String[]{"REQ"})) return args_JSON;

        String STR_REQ = JSON_REQ.getString("REQ");
        if (STR_REQ.equals("DUMMY")) {
        } else if (STR_REQ.equals("ShapesOverlaps")) {
            MakeShapesAndSorter my_MakeShapesAndSorter = new MakeShapesAndSorter();
            my_MakeShapesAndSorter.PARSE_AND_DO_TASK(args_JSON);
        } else if (STR_REQ.equals("RandomShapes")) {
            ShapeMaker my_ShapeMaker = new ShapeMaker();
            my_ShapeMaker.PARSE_AND_DO_TASK(args_JSON);
        } else if (STR_REQ.equals("RandomPolygons")) {
            RandomPolygons my_RandomPolygons = new RandomPolygons();
            my_RandomPolygons.PARSE_AND_DO_TASK(args_JSON);
        } else if (STR_REQ.equals("RandomCircles")) {
            RandomCircles my_RandomCircles = new RandomCircles();
            my_RandomCircles.PARSE_AND_DO_TASK(args_JSON);
        } else if (STR_REQ.equals("PN")) {
            PerfectNumber my_PerfectNumber = new PerfectNumber();
            my_PerfectNumber.PARSE_AND_DO_TASK(args_JSON);
        } else if (STR_REQ.equals("GCD")) {
            GCD actor_GCD = new GCD();
            actor_GCD.PARSE_AND_DO_TASK(args_JSON);
        } else {
            JSON_RES.put("STATUS", 405);
            JSON_RES.put("STATUS_MSG", String.format("REQ => [%s] 는 처리할 수 없는 요청 입니다.", STR_REQ));
        }

        return args_JSON;
    }
}
