package knu.java.HW;

import knu.java.lsy.apiTemplate.API_BACKEND;
import org.json.JSONObject;

public class GCD {
    public int find_GCD_SUB_RECURSIVE(int A, int B) {
        if (A == B) return A;
        if (A > B) {
            return find_GCD_SUB_RECURSIVE(A-B, B);
        } else {
            return find_GCD_SUB_RECURSIVE(A, B-A);
        }
    }
    public int find_GCD_EUCLID_RECURSIVE(int A, int B) {
        if ((B % A) == 0) return A;
        if ((A % B) == 0) return B;
        if (A > B) {
            return find_GCD_EUCLID_RECURSIVE(A % B, B);
        } else {
            return find_GCD_EUCLID_RECURSIVE(A, B % A);
        }
    }
    public int find_GCD_EUCLID_LOOP(int num1, int num2) {
        while (num2 != 0) {
            int temp = num2;
            num2 = num1 % num2;
            num1 = temp;
        }
        return num1;
    }
    public void PARSE_AND_DO_TASK(JSONObject args_JSON) {
        if (!API_BACKEND.IS_EXIST_ARGS(args_JSON, new String[]{"A", "B"})) {
            return;
        }

        JSONObject JSON_REQ = args_JSON.getJSONObject("REQ");
        int A = JSON_REQ.getInt("A");
        int B = JSON_REQ.getInt("B");
        JSONObject JSON_RES = args_JSON.getJSONObject("RES");

        int n_GCD_A = find_GCD_SUB_RECURSIVE(A, B);
        int n_GCD_B = find_GCD_EUCLID_RECURSIVE(A, B);
        int n_GCD_C = find_GCD_EUCLID_LOOP(A, B);

        JSON_RES.put("find_GCD_SUB_RECURSIVE", n_GCD_A);
        JSON_RES.put("find_GCD_EUCLID_RECURSIVE", n_GCD_B);
        JSON_RES.put("find_GCD_EUCLID_LOOP", n_GCD_C);

        JSON_RES.put("GCD", n_GCD_B);
        JSON_RES.put("GCD_MESSAGE",
                String.format(
                        "%d 와 %d 의 최대공약수는 %d 입니다.",
                        A, B, n_GCD_B
                )
        );
    }
}
