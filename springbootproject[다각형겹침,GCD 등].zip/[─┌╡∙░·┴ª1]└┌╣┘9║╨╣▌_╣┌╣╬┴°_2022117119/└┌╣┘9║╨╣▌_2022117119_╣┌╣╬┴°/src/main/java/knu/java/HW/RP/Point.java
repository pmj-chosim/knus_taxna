package knu.java.HW.RP;

public class Point {
    int x, y;
}
