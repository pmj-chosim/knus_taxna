package knu.java.HW.ShapesOverlaps;

import knu.java.HW.RandomShapes.*;
import knu.java.lsy.apiTemplate.API_BACKEND;
import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

public class MakeShapesAndSorter {
    ShapeMaker my_ShapeMaker;

    ArrayList<ShapeCollections> sorted_ShapeCollections = new ArrayList<>();

    public MakeShapesAndSorter() {
        my_ShapeMaker = new ShapeMaker();
    }

    boolean is_Overlap(Circle A, Circle B) {
        double distance = Math.sqrt(Math.pow(A.center_x - B.center_x, 2) + Math.pow(A.center_y - B.center_y, 2));
        return distance <= (A.radius + B.radius);
    }

    boolean is_Overlap(Circle A, Polygon B) {

        for (Point point : B.points) {
            double distance = Math.sqrt(Math.pow(A.center_x - point.x, 2) + Math.pow(A.center_y - point.y, 2));
            if (distance <= A.radius) {
                return true;
            }
        }
        return false;
    }

    boolean is_Overlap(Polygon A, Circle B) {
        return is_Overlap(B, A);
    }

    boolean is_Overlap(Polygon A, Polygon B) {

        for (Point pointA : A.points) {
            if (isPointInsidePolygon(pointA, B)) {
                return true;
            }
        }

        for (Point pointB : B.points) {
            if (isPointInsidePolygon(pointB, A)) {
                return true;
            }
        }

        return false;
    }

    boolean isPointInsidePolygon(Point point, Polygon polygon) {
        int numIntersections = 0;
        int numPoints = polygon.points.size();

        for (int i = 0; i < numPoints; i++) {
            Point p1 = polygon.points.get(i);
            Point p2 = polygon.points.get((i + 1) % numPoints);

            if ((point.y > Math.min(p1.y, p2.y)) && (point.y <= Math.max(p1.y, p2.y))) {
                double xIntersection = p1.x + (point.y - p1.y) * (p2.x - p1.x) / (p2.y - p1.y);

                if (point.x < xIntersection) {
                    numIntersections++;
                }
            }
        }

        return numIntersections % 2 == 1;
    }
    boolean is_Overlap(Shape Shape_A, Shape Shape_B) {
        if (Shape_A instanceof Circle) {
            if (Shape_B instanceof Circle) {
                return is_Overlap((Circle) Shape_A, (Circle) Shape_B);
            } else if (Shape_B instanceof Polygon) {
                return is_Overlap((Circle) Shape_A, (Polygon) Shape_B);
            }
        } else if (Shape_A instanceof Polygon) {
            if (Shape_B instanceof Circle) {
                return is_Overlap((Polygon) Shape_A, (Circle) Shape_B);
            } else if (Shape_B instanceof Polygon) {
                return is_Overlap((Polygon) Shape_A, (Polygon) Shape_B);
            }
        }
        return false;
    }

    void SortByOverlap() {
        for (Shape one_new_Shape : my_ShapeMaker.shapes) {
            boolean one_new_Shape_is_Overlapped = false;
            ArrayList<ShapeCollections> overlappedCollections = new ArrayList<>();

            for (ShapeCollections one_ShapeCollections : sorted_ShapeCollections) {
                for (Shape one_prev_Shape : one_ShapeCollections.shapes) {
                    if (is_Overlap(one_prev_Shape, one_new_Shape)) {
                        one_new_Shape_is_Overlapped = true;
                        overlappedCollections.add(one_ShapeCollections);
                        break;
                    }
                }
            }

            if (!one_new_Shape_is_Overlapped) {
                ShapeCollections new_ShapeCollections = new ShapeCollections();
                new_ShapeCollections.shapes.add(one_new_Shape);
                sorted_ShapeCollections.add(new_ShapeCollections);
            } else {
                ShapeCollections firstCollection = overlappedCollections.remove(0);
                firstCollection.shapes.add(one_new_Shape);

                for (ShapeCollections additionalCollection : overlappedCollections) {
                    firstCollection.shapes.addAll(additionalCollection.shapes);
                    sorted_ShapeCollections.remove(additionalCollection);
                }
            }
        }
    }

    public void PARSE_AND_DO_TASK(JSONObject args_JSON) {
        if (!API_BACKEND.IS_EXIST_ARGS(args_JSON,
                new String[]{
                        "Width",
                        "Height",
                        "MinRadius",
                        "MaxRadius",
                        "MaxEdges",
                        "HowMany"
                }
        )) {
            return;
        }

        JSONObject JSON_REQ = args_JSON.getJSONObject("REQ");
        JSONObject JSON_RES = args_JSON.getJSONObject("RES");

        int Width = JSON_REQ.getInt("Width");
        int Height = JSON_REQ.getInt("Height");
        int MinRadius = JSON_REQ.getInt("MinRadius");
        int MaxRadius = JSON_REQ.getInt("MaxRadius");
        int HowMany = JSON_REQ.getInt("HowMany");
        int MaxEdges = JSON_REQ.getInt("MaxEdges");

        my_ShapeMaker.make_Shapes(Width, Height, MinRadius, MaxRadius, HowMany, MaxEdges);
        SortByOverlap();

        JSON_RES.put("RESULT", toJSONObject_SORTED() );
    }

    JSONObject toJSONObject_SORTED() {
        JSONObject result_JSON = new JSONObject();

        JSONArray Collections_overlapped = new JSONArray();
        JSONArray Shapes_singles = new JSONArray();

        result_JSON.put("OVER", Collections_overlapped);
        result_JSON.put("SOLO", Shapes_singles);
        for (ShapeCollections one_ShapeCollections : sorted_ShapeCollections) {
            JSONArray Shapes_overlapped = new JSONArray();
            for (Shape one_Shape : one_ShapeCollections.shapes) {
                JSONObject one_Shape_JSON = new JSONObject();
                if (one_Shape instanceof Circle) {
                    Circle cast_Circle = (Circle) one_Shape;
                    one_Shape_JSON.put("Shape_KIND", "Circle");
                    one_Shape_JSON.put("Shape_ATTR",
                            new JSONObject()
                                    .put("x", cast_Circle.center_x)
                                    .put("y", cast_Circle.center_y)
                                    .put("radius", cast_Circle.radius)
                    );
                } else if (one_Shape instanceof Polygon) {
                    Polygon cast_Polygon = (Polygon) one_Shape;
                    one_Shape_JSON.put("Shape_KIND", "Polygon");
                    JSONArray temp_PointsArray_JSON = new JSONArray();
                    for (Point one_Point : cast_Polygon.points) {
                        JSONObject one_Point_JSON = new JSONObject();
                        one_Point_JSON.put("x", one_Point.x);
                        one_Point_JSON.put("y", one_Point.y);
                        temp_PointsArray_JSON.put(one_Point_JSON);
                    }
                    one_Shape_JSON.put("Shape_ATTR", temp_PointsArray_JSON);
                }

                if (one_ShapeCollections.shapes.size() > 1) {
                    Shapes_overlapped.put(one_Shape_JSON);
                } else {
                    Shapes_singles.put(one_Shape_JSON);
                }
            }
            if (Shapes_overlapped.length() > 0) {
                Collections_overlapped.put(Shapes_overlapped);
            }
        }

        return result_JSON;
    }

}
