package knu.java.HW.RC;

public class Circle {
    int x, y;
    int radius;
    double getArea() {
        return radius * radius * Math.PI;
    }
}
