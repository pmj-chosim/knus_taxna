package knu.java.HW;

import org.json.JSONArray;
import org.json.JSONObject;

public class JSON_EXAMPLE {
    public JSONObject make_JSON(String args_STR_JSON) {
        return new JSONObject(args_STR_JSON);
    }

    public JSONObject make_JSON() {

        JSONObject my_GlossDef = new JSONObject();
        my_GlossDef.put("para", "A meta-markup language, used to create markup languages such as DocBook.");
        my_GlossDef.put("GlossSeeAlso",
                new JSONArray()
                        .put("GML")
                        .put("XML")
        );
        my_GlossDef.put("VALUES",
                new JSONArray()
                        .put("A").put("B").put("C").put("D")
        );
        my_GlossDef.put("NUM_VALUES",
                new JSONArray()
                        .put(new JSONObject().put("A", 456))
                        .put(new JSONObject().put("A", 789).put("B", "MORE"))
        );


        JSONObject my_GlossEntry = new JSONObject();
        my_GlossEntry.put("ID", "SGML");
        my_GlossEntry.put("SortAs", "SGML");
        my_GlossEntry.put("GlossTerm", "Standard Generalized Markup Language");
        my_GlossEntry.put("Acronym", "SGML");
        my_GlossEntry.put("Abbrev", "ISO 8879:1986");
        my_GlossEntry.put("GlossDef", my_GlossDef);

        JSONObject result = new JSONObject();
        result.put(
                "glossary",
                new JSONObject()
                        .put("title", "example glossary")
                        .put("GlossDiv",
                                new JSONObject()
                                        .put("title", "S")
                                        .put("GlossList",
                                                new JSONObject()
                                                        .put("GlossEntry", my_GlossEntry)
                                        )
                        )
        );
        return result;
    }

    public static void main(String[] args) {
        System.out.println("Hello world!");
        JSON_EXAMPLE my_JSON_EXAMPLE = new JSON_EXAMPLE();
        JSONObject maked_JSON = my_JSON_EXAMPLE.make_JSON();

        System.out.println("" + maked_JSON);
        System.out.println(maked_JSON.toString(3));
    }

}
