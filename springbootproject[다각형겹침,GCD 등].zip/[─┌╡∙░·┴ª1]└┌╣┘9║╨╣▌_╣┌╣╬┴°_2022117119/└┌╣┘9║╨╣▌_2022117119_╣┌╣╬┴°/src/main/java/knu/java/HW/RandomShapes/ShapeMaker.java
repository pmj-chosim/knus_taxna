package knu.java.HW.RandomShapes;

import knu.java.lsy.apiTemplate.API_BACKEND;
import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

public class ShapeMaker {
    public ArrayList<Shape> shapes = new ArrayList<>();

    public JSONArray toJSONArray() {
        JSONArray RESULT_JSONArray = new JSONArray();
        for (Shape one_Shape : shapes) {
            if (one_Shape instanceof Circle) {
                Circle cast_Circle = (Circle) one_Shape;
                JSONObject temp_Circle_JSON = new JSONObject();
                temp_Circle_JSON.put("Shape_KIND", "Circle");
                temp_Circle_JSON.put("Shape_ATTR",
                    new JSONObject()
                            .put("x", cast_Circle.center_x)
                            .put("y", cast_Circle.center_y)
                            .put("radius", cast_Circle.radius)
                );
                RESULT_JSONArray.put(temp_Circle_JSON);

            } else if (one_Shape instanceof Polygon) {
                Polygon cast_Polygon = (Polygon) one_Shape;
                JSONObject temp_Polygon_JSON = new JSONObject();
                temp_Polygon_JSON.put("Shape_KIND", "Polygon");
                JSONArray temp_PointsArray_JSON = new JSONArray();
                for (Point one_Point : cast_Polygon.points) {
                    JSONObject one_Point_JSON = new JSONObject();
                    one_Point_JSON.put("x", one_Point.x);
                    one_Point_JSON.put("y", one_Point.y);
                    temp_PointsArray_JSON.put(one_Point_JSON);
                }
                temp_Polygon_JSON.put("Shape_ATTR", temp_PointsArray_JSON);

                RESULT_JSONArray.put(temp_Polygon_JSON);
            }

        }
        return  RESULT_JSONArray;
    }
    public void make_Shapes(
        int Width,
        int Height,
        int MinRadius,
        int MaxRadius,
        int HowMany,
        int MaxEdges
    ) {
        for (int i=0; i < HowMany; i++) {
            int MAKE_WHAT = (int) (Math.random() * 2);
            if (MAKE_WHAT == 0) {
                Circle temp_Circle = new Circle();
                temp_Circle.make_Circle(Width, Height, MinRadius, MaxRadius);
                shapes.add(temp_Circle);
            } else {
                Polygon temp_Polygon = new Polygon();
                temp_Polygon.make_Polygon(Width, Height, MinRadius, MaxRadius, MaxEdges);
                shapes.add(temp_Polygon);
            }
        }
    }

    public void PARSE_AND_DO_TASK(JSONObject args_JSON) {
        if (!API_BACKEND.IS_EXIST_ARGS(args_JSON,
                new String[]{
                        "Width",
                        "Height",
                        "MinRadius",
                        "MaxRadius",
                        "MaxEdges",
                        "HowMany"
                }
        )) {
            return;
        }

        JSONObject JSON_REQ = args_JSON.getJSONObject("REQ");
        JSONObject JSON_RES = args_JSON.getJSONObject("RES");

        int Width = JSON_REQ.getInt("Width");
        int Height = JSON_REQ.getInt("Height");
        int MinRadius = JSON_REQ.getInt("MinRadius");
        int MaxRadius = JSON_REQ.getInt("MaxRadius");
        int HowMany = JSON_REQ.getInt("HowMany");
        int MaxEdges = JSON_REQ.getInt("MaxEdges");

        make_Shapes(Width, Height, MinRadius, MaxRadius, HowMany, MaxEdges);

        JSON_RES.put("RESULT", toJSONArray());
    }

}
