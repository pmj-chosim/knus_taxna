package knu.java.HW.RP;

import knu.java.lsy.apiTemplate.API_BACKEND;
import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

public class RandomPolygons {
    ArrayList<Polygon> polygons = new ArrayList<>();

    public void make_Polygons(
            int Width,
            int Height,
            int MinRadius,
            int MaxRadius,
            int HowMany,
            int MaxEdges
   ) {
        for (int i=0; i < HowMany; i++) {
            Polygon temp_Polygon = new Polygon();
            temp_Polygon.make_Polygon(Width,Height,MinRadius,MaxRadius,MaxEdges);
            polygons.add(temp_Polygon);
        }
    }

    public JSONArray toJSONArray() {
        JSONArray temp_JSONArray = new JSONArray();

        for(Polygon one_Polygon : polygons) {
            JSONArray one_Polygon_JSON = new JSONArray();
            for(Point one_Point : one_Polygon.points) {
                JSONObject temp_JSONObject = new JSONObject();
                temp_JSONObject.put("x", one_Point.x);
                temp_JSONObject.put("y", one_Point.y);
                one_Polygon_JSON.put(temp_JSONObject);
            }
            temp_JSONArray.put(one_Polygon_JSON);
        }

        return temp_JSONArray;
    }

    public void PARSE_AND_DO_TASK(JSONObject args_JSON) {
        if (!API_BACKEND.IS_EXIST_ARGS(args_JSON,
                new String[]{
                        "Width",
                        "Height",
                        "MinRadius",
                        "MaxRadius",
                        "MaxEdges",
                        "HowMany"
                }
        )) {
            return;
        }

        JSONObject JSON_REQ = args_JSON.getJSONObject("REQ");
        JSONObject JSON_RES = args_JSON.getJSONObject("RES");
        int Width = JSON_REQ.getInt("Width");
        int Height = JSON_REQ.getInt("Height");
        int MinRadius = JSON_REQ.getInt("MinRadius");
        int MaxRadius = JSON_REQ.getInt("MaxRadius");
        int HowMany = JSON_REQ.getInt("HowMany");
        int MaxEdges = JSON_REQ.getInt("MaxEdges");

        make_Polygons(Width, Height, MinRadius, MaxRadius, HowMany, MaxEdges);

        JSON_RES.put("RESULT", toJSONArray());
    }

}
