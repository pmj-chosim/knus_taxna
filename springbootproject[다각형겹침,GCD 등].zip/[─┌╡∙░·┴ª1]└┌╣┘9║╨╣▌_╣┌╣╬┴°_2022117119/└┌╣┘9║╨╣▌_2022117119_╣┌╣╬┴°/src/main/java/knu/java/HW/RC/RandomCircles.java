package knu.java.HW.RC;

import knu.java.lsy.apiTemplate.API_BACKEND;
import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

public class RandomCircles {
    ArrayList<Circle> circles;

    public RandomCircles() {
        circles = new ArrayList<>();
    }

    public JSONArray toJSONArray() {
        JSONArray temp_JSONArray = new JSONArray();
        for(Circle one_circle : circles) {
            JSONObject temp_JSONObject = new JSONObject();
            temp_JSONObject.put("x", one_circle.x);
            temp_JSONObject.put("y", one_circle.y);
            temp_JSONObject.put("radius", one_circle.radius);
            temp_JSONArray.put(temp_JSONObject);
        }
        return temp_JSONArray;
    }

    public void make_Circles(
        int Width,
        int Height,
        int MaxRadius,
        int MinRadius,
        int HowMany
    ) {
        for(int i=0; i<HowMany; i++) {
            Circle temp_Circle = new Circle();
            temp_Circle.x = (int) (Math.random() * (Width - MaxRadius * 2) + MaxRadius);
            temp_Circle.y = (int) (Math.random() * (Height - MaxRadius * 2) + MaxRadius);
            temp_Circle.radius = (int) (Math.random() * Math.abs(MaxRadius - MinRadius) + (MaxRadius > MinRadius ? MinRadius : MaxRadius));
            circles.add(temp_Circle);
        }
    }

    public void PARSE_AND_DO_TASK(JSONObject args_JSON) {
        if (!API_BACKEND.IS_EXIST_ARGS(args_JSON,
                new String[]{
                    "Width",
                    "Height",
                    "MinRadius",
                    "MaxRadius",
                    "HowMany"
                }
        )) {
            return;
        }

        JSONObject JSON_REQ = args_JSON.getJSONObject("REQ");
        JSONObject JSON_RES = args_JSON.getJSONObject("RES");
        int Width = JSON_REQ.getInt("Width");
        int Height = JSON_REQ.getInt("Height");
        int MinRadius = JSON_REQ.getInt("MinRadius");
        int MaxRadius = JSON_REQ.getInt("MaxRadius");
        int HowMany = JSON_REQ.getInt("HowMany");

        make_Circles(Width, Height, MaxRadius, MinRadius, HowMany);

        JSON_RES.put("RESULT", toJSONArray());
    }

    /*
    public static void main(String[] arg) {
        RandomCircles my_RandomCircles = new RandomCircles();
        my_RandomCircles.make_Circles(
                800,
                500,
                50,
                5,
                70
        );

        System.out.println(my_RandomCircles.circles);
    }
    // */

}
