package knu.java.lsy.apiTemplate;

import knu.java.lsy.UTILS.UTIL;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.io.File;

@SpringBootApplication
public class ApiTemplateApplication {
	public static void main(String[] args) {
		SpringApplication.run(ApiTemplateApplication.class, args);
	}
}
