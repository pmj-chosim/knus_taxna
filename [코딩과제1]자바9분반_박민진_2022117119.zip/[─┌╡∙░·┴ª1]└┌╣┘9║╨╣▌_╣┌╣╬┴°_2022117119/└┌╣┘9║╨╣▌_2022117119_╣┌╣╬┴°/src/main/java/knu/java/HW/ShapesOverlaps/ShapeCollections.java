package knu.java.HW.ShapesOverlaps;

import knu.java.HW.RandomShapes.Shape;

import java.util.ArrayList;

public class ShapeCollections {
    ArrayList<Shape> shapes = new ArrayList<>();
}
