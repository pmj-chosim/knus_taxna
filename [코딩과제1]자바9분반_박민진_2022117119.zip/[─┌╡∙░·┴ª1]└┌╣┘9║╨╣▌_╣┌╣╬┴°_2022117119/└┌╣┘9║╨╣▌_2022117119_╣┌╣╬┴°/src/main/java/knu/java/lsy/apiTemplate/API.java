package knu.java.lsy.apiTemplate;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.Map;

@RestController
public class API {
    @RequestMapping("/api")
    @CrossOrigin(origins = "*", allowedHeaders = "*")
    public String requestParams(HttpServletRequest request, HttpServletResponse response) throws IOException {

        JSONObject params_JSON = new JSONObject();

        Map<String, String[]> ARGS_MAP = request.getParameterMap();
        for (String STR_KEY : ARGS_MAP.keySet()) {
            params_JSON.put(STR_KEY, ARGS_MAP.get(STR_KEY)[0]);
        }

        JSONObject JSON_RES = new JSONObject()
                .put("STATUS", 200)
                .put("STATUS_MSG", "OK");

        JSONObject JSON_RESPONSE = new JSONObject();
        JSON_RESPONSE.put("REQ", params_JSON);
        JSON_RESPONSE.put("RES", JSON_RES);

        try {
            API_BACKEND.DO_REQ(JSON_RESPONSE);
        } catch (Exception e) {
            StringWriter sw = new StringWriter();
            PrintWriter pw = new PrintWriter(sw);
            e.printStackTrace(pw);
            String[] STR_LINES = sw.toString().split("\r\n");
            JSONArray JSON_ARRAY_StackTrace = new JSONArray();
            for(String s : STR_LINES) {
                JSON_ARRAY_StackTrace.put(s);
            }
            JSON_RES.put("StackTrace", JSON_ARRAY_StackTrace);
        }

        return JSON_RESPONSE.toString();
    }
}
