package knu.java.HW;

import knu.java.lsy.apiTemplate.API_BACKEND;
import org.json.JSONArray;
import org.json.JSONObject;

public class PerfectNumber {
    public JSONArray get_PerfectNumber(int limit) {
        JSONArray RESULT = new JSONArray();
        for (int i = 1; i <= limit; i++) {
            int sum = 0;
            for (int j = 1; j < i; j++) {
                if (i % j == 0) {
                    sum += j;
                }
            }
            if (sum == i) {
                RESULT.put(i);
            }
        }
        return RESULT;
    }

    public void PARSE_AND_DO_TASK(JSONObject args_JSON) {
        if (!API_BACKEND.IS_EXIST_ARGS(args_JSON, new String[]{"N"})) {
            return;
        }

        JSONObject JSON_REQ = args_JSON.getJSONObject("REQ");
        int N = JSON_REQ.getInt("N");
        JSONObject JSON_RES = args_JSON.getJSONObject("RES");

        JSONArray result = get_PerfectNumber(N);

        JSON_RES.put("Perfect_Numbers", result);
        JSON_RES.put("Perfect_Numbers_MESSAGE",
                String.format(
                        "1 부터 %d 까지의 완전수 는 %s 입니다.",
                        N, result.toString()
                )
        );
    }


}
