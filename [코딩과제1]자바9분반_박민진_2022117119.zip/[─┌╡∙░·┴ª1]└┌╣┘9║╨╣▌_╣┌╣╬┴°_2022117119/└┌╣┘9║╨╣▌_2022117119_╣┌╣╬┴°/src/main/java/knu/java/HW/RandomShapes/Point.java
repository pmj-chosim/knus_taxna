package knu.java.HW.RandomShapes;

public class Point {
    public int x, y;
}
