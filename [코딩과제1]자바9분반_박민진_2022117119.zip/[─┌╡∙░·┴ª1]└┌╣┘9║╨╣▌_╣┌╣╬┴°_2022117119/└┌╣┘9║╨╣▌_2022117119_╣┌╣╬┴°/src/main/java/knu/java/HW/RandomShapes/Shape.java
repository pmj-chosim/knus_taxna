package knu.java.HW.RandomShapes;

public class Shape {
    public int center_x;
    public int center_y;
}
