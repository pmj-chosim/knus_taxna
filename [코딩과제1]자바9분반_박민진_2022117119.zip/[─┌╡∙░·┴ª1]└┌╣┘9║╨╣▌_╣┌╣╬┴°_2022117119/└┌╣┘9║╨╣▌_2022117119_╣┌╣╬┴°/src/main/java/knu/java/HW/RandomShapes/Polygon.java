package knu.java.HW.RandomShapes;

import java.util.ArrayList;

public class Polygon extends Shape {
    public ArrayList<Point> points = new ArrayList<>();

    public void make_Polygon(
            int Width,
            int Height,
            int MinRadius,
            int MaxRadius,
            int MaxEdges
    ) {
        center_x = (int) (Math.random() * (Width - MaxRadius * 2) + MaxRadius);
        center_y = (int) (Math.random() * (Height - MaxRadius * 2) + MaxRadius);

        int edge_count = (int) (Math.random() * (MaxEdges - 2)) + 3;
        int degree_step = (int) (360.0 / edge_count);
        for(int e = 0; e < edge_count; e += 1) {
            Point temp_Point = new Point();
            int temp_Radius = (int) (Math.random() * Math.abs(MaxRadius - MinRadius) + MinRadius);
            int degree = (int) (Math.random() * degree_step + e * degree_step);
            temp_Point.x = (int) (temp_Radius * Math.sin(Math.toRadians(degree)) + center_x);
            temp_Point.y = (int) (temp_Radius * Math.cos(Math.toRadians(degree)) + center_y);
            points.add(temp_Point);
        }
    }

}
